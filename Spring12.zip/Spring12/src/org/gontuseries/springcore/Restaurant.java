package org.gontuseries.springcore;

public class Restaurant {

	public void greetCustomer() {

		System.out.println("welcome dear customer!! this is the LifeCycle demo");
	}
	
	public void init() {
		System.out.println("Restaurant Bean is going through init.");
	}

	public void destroy() {
		System.out.println("Bean will destroy now.");
	}

}