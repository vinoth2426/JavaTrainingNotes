package com.gontuseries.springcore;

/**
 * Spring bean
 * 
 */
public class Restaurant {

	public void greetCustomer() {

		System.out.println("welcome to our restaurant!!");
	}
}