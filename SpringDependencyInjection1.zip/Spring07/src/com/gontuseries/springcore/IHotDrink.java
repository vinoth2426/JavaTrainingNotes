package com.gontuseries.springcore;

public interface IHotDrink {

	public void prepareHotDrink();
}
