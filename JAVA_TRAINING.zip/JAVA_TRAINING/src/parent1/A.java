package parent1;

public class A {
	
	
	public void disp()
	{
		System.out.println(" Hi Disp Method");
	}

}
