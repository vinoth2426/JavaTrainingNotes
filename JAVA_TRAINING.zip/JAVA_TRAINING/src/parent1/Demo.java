package parent1;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a=new A();
		B b=new B();
		a.disp();
		b.Hai();

	}

}
