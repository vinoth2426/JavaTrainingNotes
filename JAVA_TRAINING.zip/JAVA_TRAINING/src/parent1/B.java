package parent1;

public class B {

	public void Hai()
	{
		System.out.println("Hi Method");
	}
}
