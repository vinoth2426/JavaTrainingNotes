/**
 * 
 */
package Sample;

/**
 * @author vinothvino
 *
 */
public class A {
	
	void disp()
	{
		System.out.println("A Method Calling");
	}

}
