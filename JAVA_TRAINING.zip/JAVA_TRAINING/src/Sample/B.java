/**
 * 
 */
package Sample;

/**
 * @author vinothvino
 *
 */
public class B {
	
	void disp1()
	{
		System.out.println("B Method Calling");
	}


}
