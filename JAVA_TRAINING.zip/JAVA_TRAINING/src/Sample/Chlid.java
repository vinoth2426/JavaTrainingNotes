package Sample;

public class Chlid {
	
	public static void main(String args[])
	{
		A a=new A();
		B b=new B();
		a.disp();
		b.disp1();
	}

}
