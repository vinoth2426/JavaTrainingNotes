package Constructor;

public class DefaultConstructor {
	
	DefaultConstructor()//constructor
	{
		System.out.println(" Hi I am Default Constructor");
	}
	public static void main(String args[]){  
		DefaultConstructor b=new DefaultConstructor();  
		
		}  
}
