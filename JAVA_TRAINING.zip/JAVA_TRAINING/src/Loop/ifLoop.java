package Loop;

 class ifLoop {
	public static void main(String args[])
	{
		int a=1;
		if(a==0)
		{
			System.out.println("The Loop Enter");
		}
		else{
		System.out.println("Reset Code");
		}
	}
	
	
}
