package Loop;

public class whileLoop {
	public static void main(String args[])
	{
		int a=2;//variable init
		while(a<20)
		{
			System.out.println(" The Value of"+a);
			a++;
			System.out.println("\n");
	
		}
		
		System.out.println("Reset the Code");
		
	}
	

}
