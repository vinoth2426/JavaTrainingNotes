package Loop;

public class InfiniteLoop {
	public static void main(String[] args) {
		   
	    /*
	     * Its perfectely legal to skip any of the 3 parts of the for loop.
	     * Below given for loop will run infinite times.
	     */
	     for(;;)
	       System.out.println("Hello");
	     
	     /*
	      * To terminate this program press ctrl + c in the console.
	      */
	  }
	}
	 


