package Loop;

public class ifelseLoop {
	public static void main(String args[])
	{
		int a=5;
		if(a==0)
		{
			System.out.println("Equal To Zero");
		}
		
		else if(a==4)
		{
			System.out.println("Not Equal");
			
		}
		
		else
		{
			System.out.println(" Reset The Code");	
		}
		//System.out.println(" Reset The Code");
	}

}
