package Loop;

/*Syntax:
 * for( <initialization> ; <condition> ; <statement> ){
 
        <Block of statements>;
 
}
 */


public class ForLoop { // Main Class
	public static void main(String args[])// Main Method
	{
		
		for(  int a=10; a<=100;a++)// Looping concept
		{
			System.out.println(a);
		}
		//System.out.println("OUT OF  THE LOOP");
	}

}
