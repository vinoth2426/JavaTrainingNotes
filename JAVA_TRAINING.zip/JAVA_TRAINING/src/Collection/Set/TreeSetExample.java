package Collection.Set;

import java.util.SortedSet;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String args[])
	{
		
	SortedSet s1=new TreeSet();
	

	s1.add(new Integer (10));
	
	System.out.println(s1);
}
}
