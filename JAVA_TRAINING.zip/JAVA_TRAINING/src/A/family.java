package A;

public class family {
void fam()
{
	System.out.println("WELCOME");
	
}
}
