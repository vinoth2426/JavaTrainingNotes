package A;

public class Child {
	public static void main(String args[])
	{
	
		family f=new family();
	Parent p=new Parent();
	p.sum();
	f.fam();


}
}