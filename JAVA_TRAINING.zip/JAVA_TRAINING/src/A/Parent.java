package A;

public class Parent {
	
	void sum()
	{
		System.out.println("HAI DAD");
	}

}
