package Keywords;

class Bike9{  
	 final int speedlimit=90;//final variable  
	 void run(){  
   //speedlimit=100;  
	 }  
	 public static void main(String args[]){  
	 Bike9 obj=new  Bike9();  
	 obj.run();  
	 }  
	}//end of class 
