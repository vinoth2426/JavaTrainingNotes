package com.applet;

import java.applet.Applet;
import java.awt.Graphics;

public class Sample extends Applet{  
	  
public void paint(Graphics g){  
g.drawString("welcome",150,150);  
}  

}
