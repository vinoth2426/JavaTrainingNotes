
package com.applet;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Date;

public class WelcomeApplet1 extends Applet {
     public void paint(Graphics g)
     {
        g.drawString("WELCOME SERVLET", 300, 180);
        
    }
    
}
