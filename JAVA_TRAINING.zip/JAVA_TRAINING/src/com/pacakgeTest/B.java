package com.pacakgeTest;

public class B {
	void display()
	{
		System.out.println("TEST TEST>>>>>>>>>>>>");
	}

}
