package com.pacakgeTest;

public class A {
	
	void sum()
	{
		System.out.println("Test1");
	}

}
