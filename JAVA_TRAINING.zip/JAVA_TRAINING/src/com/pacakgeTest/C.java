package com.pacakgeTest;



public class C {
	public static void main(String args[])
	{
		A a=new A();
		//B b=new B();
		a.sum();
		//b.display();
		
	}

}
