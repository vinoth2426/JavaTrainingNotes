package BasicJava;

public class A {
	public static void main(String args[])
	{
		String obj=new String("XYZ");
		String obj1=new String("XYZ");
		if(obj==obj1)
			System.out.println("obj==obj1 is true");
		else
			System.out.println("obj==obj1 is false");
			
	}

}
