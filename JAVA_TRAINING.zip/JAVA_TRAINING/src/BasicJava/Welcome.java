package BasicJava;

public class Welcome {
	int a,b,c;
void print(int a,int b)
{
	
	int c=a+b;
	System.out.println("THE ADD"+c);
}
	public static void main(String args[])
	{
Welcome w=new Welcome();
     w.print(20,45);
	}
	
}
