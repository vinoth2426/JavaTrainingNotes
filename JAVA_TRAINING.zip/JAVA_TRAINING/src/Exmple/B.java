package Exmple;

public class B {

	void IIT()
	{
		System.out.println("IIT GUYS");
	}
	
}
