package Exmple;

public class Demo {
	
	public static void main(String args[])
	{
		A a=new A();
		a.SRM();
		
		B b=new B();
		b.IIT();
	}

}
