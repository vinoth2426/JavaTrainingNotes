package Exmple;

public class A {

	void SRM()
	{
		
		System.out.println("HELLO SRM COLLEGE");
	}
	
}
