package Exception;
public class Excep6 {  
    static void throwone() throws Exception,NullPointerException
    {
        System.out.println(" I AM Null");
                throw new NullPointerException("Demo");
    }
    public static void main(String args[]) throws Exception
    {
        try
        {
         throwone();
        }
        catch(NullPointerException e)
        {
            System.out.println("caught"+e);
        }
    }
}
