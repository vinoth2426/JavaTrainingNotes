package StudentPackage;

public class Student2 {
	
	public void EEEStudentDetails()
	{
		System.out.println("EEE GUYS WELCOME");
	}

}
