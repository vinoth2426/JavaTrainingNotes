package StudentPackage;

public class Stduent1 {
	
	public void ECEStudentDetails()
	{
		System.out.println("ECE GUYS WELCOME");
	}

}
