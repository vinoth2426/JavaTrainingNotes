package StudentPackage;

public class College {
	public static void main(String args[])
	{
		Stduent1 s =new Stduent1();
		Student2 s1=new Student2();
		s.ECEStudentDetails();
		s1.EEEStudentDetails();
		
	}

}
