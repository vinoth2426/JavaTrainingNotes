
package Parent;

public class B {
     public void disp()
    {
        System.out.println("Hi Arif");
    }
    
}
