
package Parent;
public class A {
	int a;
    public void disp()
    {
        System.out.println("Hi Vinoth");
    }
}
