package p2;
public class Baes2 extends p1.Base

{
    
  Baes2()
  {
	// System.out.println("n="+n);
    //System.out.println("n_pri="+n_pri);
      System.out.println("Base2 Constructor");
      System.out.println("n_pro="+n_pro);
      System.out.println("n_pub="+n_pub);
      
  }
  }
