package p2;
public class Demo1 {
    public static void main(String args[])
    {
      Baes2 b2=new Baes2();
      //OtherPacakge ob=new OtherPacakge();
    }
    }
