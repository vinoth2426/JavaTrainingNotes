/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2;

/**
 *
 * @author VINOTHVINO
 */
public class OtherPacakge {
    
    OtherPacakge()
            
    {
        p1.Base p=new p1.Base();
        System .out.println("Other Pacakge Constructor");
     //   System.out.println("n_pub="+p.n_pro);
        System.out.println("n_pub="+p.n_pub);
    }
}
