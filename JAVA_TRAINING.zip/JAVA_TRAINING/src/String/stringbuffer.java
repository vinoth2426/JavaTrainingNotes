/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package String;

/**
 *
 * @author VINOTHVINO
 */
public class stringbuffer {
    public static void main(String args[])
    {
        StringBuffer s=new StringBuffer("HostName");
        s.append("Come");
        s.append("JAVA");
        System.out.println("The StringBuffer Is:"+s);
    }
    
   
}
